package com.example.payment.service;

import com.example.payment.entity.Payment;
import com.example.payment.entity.PendingOrderAmount;
import com.example.payment.event.PaymentCompletedEvent;
import com.example.payment.event.PaymentFailedEvent;
import com.example.payment.messaging.PaymentEventProducer;
import com.example.payment.repository.PaymentRepository;
import com.example.payment.repository.PendingOrderAmountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository paymentRepository;
    private final PendingOrderAmountRepository pendingOrderAmountRepository;
    private final PaymentEventProducer eventProducer;

    // Failure injection: any order for a productId in this list always
    // fails payment, deterministically. Configured via:
    //   payment.failing-product-ids=2
    // Comma-separated list of Longs. Empty by default (nothing fails).
    private final List<Long> failingProductIds;

    public PaymentService(PaymentRepository paymentRepository,
                          PendingOrderAmountRepository pendingOrderAmountRepository,
                          PaymentEventProducer eventProducer,
                          @Value("${payment.failing-product-ids:}") List<Long> failingProductIds) {
        this.paymentRepository = paymentRepository;
        this.pendingOrderAmountRepository = pendingOrderAmountRepository;
        this.eventProducer = eventProducer;
        this.failingProductIds = failingProductIds;
    }

    @Transactional
    public void processPayment(Long orderId, Long productId, Integer quantity) {
        if (paymentRepository.existsById(orderId)) {
            log.info("Payment for orderId={} already processed, skipping duplicate delivery", orderId);
            return;
        }

        BigDecimal amount = pendingOrderAmountRepository.findById(orderId)
                .map(PendingOrderAmount::getTotalAmount)
                .orElse(null);

        if (amount == null) {
            log.warn("No cached amount found for orderId={}, failing payment", orderId);
            failPayment(orderId, productId, quantity, null, "Order amount not found");
            return;
        }

        if (failingProductIds.contains(productId)) {
            log.info("productId={} is configured to always fail payment (orderId={})", productId, orderId);
            failPayment(orderId, productId, quantity, amount, "Payment declined (simulated failure)");
            return;
        }

        Payment payment = new Payment(orderId, amount, Payment.PaymentStatus.SUCCESS, null);
        paymentRepository.save(payment);

        eventProducer.publishPaymentCompleted(new PaymentCompletedEvent(orderId, amount));
        log.info("Payment SUCCEEDED for orderId={}, amount={}", orderId, amount);
    }

    private void failPayment(Long orderId, Long productId, Integer quantity, BigDecimal amount, String reason) {
        Payment payment = new Payment(
                orderId, amount != null ? amount : BigDecimal.ZERO, Payment.PaymentStatus.FAILED, reason);
        paymentRepository.save(payment);

        eventProducer.publishPaymentFailed(new PaymentFailedEvent(orderId, productId, quantity, reason));
        log.info("Payment FAILED for orderId={}: {}", orderId, reason);
    }
}
package com.example.payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentApplicationTests {

    @Test
    void contextLoads() {
        // Requires a running Postgres (paymentdb) AND Kafka broker.
    }
}